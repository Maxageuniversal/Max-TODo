<?php

use function Livewire\Volt\{state, with};
use App\Models\Todo;
use App\Mail\TodoCreated; // Import the TodoCreated Mailable class
use Illuminate\Support\Facades\Mail; // Import the Mail facade
state(['task']);

with([
    'todos' => fn() => auth()->user()->todos,
]);

$add = function () {
    $todo = auth()
        ->user()
        ->todos()
        ->create([
            'task' => $this->task,
        ]);

    Mail::to(auth()->user())->queue(new TodoCreated($todo));

    $this->task = '';
};

$delete = fn(Todo $todo) => $todo->delete();
?>

<div>
    <form wire:submit.prevent="add" class="flex items-center" style="margin-bottom: 27px;">
        <input
            class="border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm mt-1 block w-full"
            type="text" wire:model="task"
            class="rounded-l-lg p-2 border-t border-b border-l text-gray-800 border-gray-200 bg-white"
            placeholder="Task...">


        <x-primary-button type="submit" style="    margin-top: 4px;
        height: 37px;">
            Create
        </x-primary-button>
    </form>


    @foreach ($todos as $todo)
        <div>
            {{ $todo->task }}

            <div style="display: flex; justify-content: flex-end; margin-top: -29px;">
                <x-primary-button wire:click='delete({{ $todo->id }})'
                    style="background-color: rgba(238, 229, 217, 0.629); margin-left: 10px;">
                    x
                </x-primary-button>

            </div>

        </div>
    @endforeach
</div>
