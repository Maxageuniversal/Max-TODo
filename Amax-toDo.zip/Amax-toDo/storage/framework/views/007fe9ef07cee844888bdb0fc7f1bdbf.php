<div>
    <form wire:submit='add'>
        <input type='text' wire:model='task'>
        <button TYPe='submit'>Add</button>
    </form>
</div><?php /**PATH C:\Users\MY COMPUTER\Desktop\mind\my-todo-project\resources\views\livewire/todos.blade.php ENDPATH**/ ?>