<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;

Artisan::command('todos:overdue', function () {
    // Your command logic goes here
})->daily()
  ->at('06:00')
  ->timezone('Europe/London')
  ->weekdays();
